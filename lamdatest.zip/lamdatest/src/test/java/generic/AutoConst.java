package generic;

public interface AutoConst 
{
	String CHROME_KEY="webdriver.chrome.driver";
	String CHROME_VALUE="C:\\Users\\Administrator\\eclipse-workspace\\Automation\\Drivers\\chromedriver.exe";
	String APP_URL=" ";
	
}
