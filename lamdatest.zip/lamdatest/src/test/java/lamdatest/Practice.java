package lamdatest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Practice extends BasePage  {
	
	
    
	

	@Test
	public void TC()
	{
		WebElement name = driver.findElement(By.xpath("//input[@name='firstname']"));
		name.sendKeys("Gaurav");
		
		WebElement lastName = driver.findElement(By.xpath("//input[@name='lastname']"));
		lastName.sendKeys("Golani");
		
		WebElement sex = driver.findElement(By.xpath("//input[@id='sex-0']"));
		sex.click();
		
		WebElement yoe = driver.findElement(By.xpath("//input[@id='exp-4']"));
		yoe.click();
		
		WebElement date = driver.findElement(By.xpath("//input[@id='datepicker']"));
		date.sendKeys("03/07/2022");
		
		WebElement MT = driver.findElement(By.xpath("//input[@id='profession-0']"));
		MT.click();
		
		WebElement AT = driver.findElement(By.xpath("//input[@id='profession-1']"));
		AT.click();
		
		WebElement automationTools = driver.findElement(By.xpath("//input[@id='tool-2']"));
		automationTools.click();
		
		Select dropdown = new Select(driver.findElement(By.xpath("//select[@id='continents']")));
		dropdown.selectByVisibleText("Australia");
		
		WebElement commands = driver.findElement(By.xpath("//option[contains(text(),'Browser Commands')]"));
		commands.click();
		
		
		
	}

}
