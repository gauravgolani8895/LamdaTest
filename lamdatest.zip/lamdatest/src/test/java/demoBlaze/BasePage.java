package demoBlaze;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BasePage {
	
	public static WebDriver driver=null;
	@BeforeMethod
	 public void launchApp()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\eclipse-workspace\\lamdatest\\Drivers\\chromedriver.exe");
	driver=new ChromeDriver();
    
	driver.manage().window().maximize();
	driver.manage().deleteAllCookies();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get("https://www.demoblaze.com/index.html");
	}
	
	@AfterMethod
	public void closeApp()
	{
		driver.close();
	}

}
