package demoBlaze;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class E2E extends Cart{
	
	@Test
	public void  TC() throws InterruptedException
	{
		WebElement s6 = driver.findElement(By.xpath("//a[starts-with(text(),'Samsung galaxy s6')]"));
		s6.click();
		
		WebElement add2Cart = driver.findElement(By.xpath("//a[starts-with(text(),'Add to cart')]"));
		add2Cart.click();
		
		Thread.sleep(3000);
		
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		
		Cart a = new Cart();
		a.cart();
	}

}
