package demoBlaze;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Login extends BasePage{
	
	@Test
	public void login()
	{
		WebElement login = driver.findElement(By.xpath("//a[contains(text(),'Log in')]")) ;
		login.click();
		
		WebElement username = driver.findElement(By.xpath("//input[@id='loginusername']")) ;
		username.sendKeys("gaurav_golani");
		
		WebElement pwd = driver.findElement(By.xpath("//input[@id='loginpassword']")) ;
		pwd.sendKeys("gaurav123");
		
		driver.findElement(By.xpath("//button[contains(text(),'Log in')]")).click();
		
		Boolean isPresent = driver.findElements(By.xpath("//a[contains(text(),'Welcome')]")).size() > 0;
		
	}

}
