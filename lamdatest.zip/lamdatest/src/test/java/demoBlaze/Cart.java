package demoBlaze;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Cart extends BasePage {
	@Test
	public void cart()
	{
		WebElement cart = driver.findElement(By.xpath("//a[contains(text(),'Cart')]")) ;
		cart.click();
		
		WebElement placeOrder = driver.findElement(By.xpath("//button[contains(text(),'Place Order')]")) ;
		placeOrder.click();
		
		WebElement name = driver.findElement(By.xpath("//input[@id='name']")) ;
		name.sendKeys("gaurav");
		
		WebElement country = driver.findElement(By.xpath("//input[@id='country']")) ;
		country.sendKeys("India");
		
		WebElement creditCard = driver.findElement(By.xpath("//input[@id='card']")) ;
		creditCard.sendKeys("001");
		
		driver.findElement(By.xpath("//button[starts-with(text(),'Purchase')]")).click();
		
		String expMsg="Thank you for your purchase!";
		 String  msg=driver.findElement(By.xpath("//h2[starts-with(text(),'Thank you for your purchase!')]")).getText();
		
		 
		 Assert.assertEquals(msg, expMsg);
		 
		
		
	}

}
