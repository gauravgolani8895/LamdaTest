package demoBlaze;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Contact extends BasePage {

	@Test
	public void contact()
	{
		WebElement contact = driver.findElement(By.xpath("//a[contains(text(),'Contact')]")) ;
		contact.click();
		
		WebElement contactEmail = driver.findElement(By.xpath("//input[@id='recipient-email']")) ;
		contactEmail.sendKeys("ABC@gmail.com");
		
		WebElement contactName = driver.findElement(By.xpath("//input[@id='recipient-name']")) ;
		contactName.sendKeys("GG");
		
		WebElement message = driver.findElement(By.xpath("//textarea")) ;
		message.sendKeys("call me asap");
		
		WebElement sendMessage = driver.findElement(By.xpath("//button[starts-with(text(),'Send message')]")) ;
		sendMessage.click();
		
	}
}
