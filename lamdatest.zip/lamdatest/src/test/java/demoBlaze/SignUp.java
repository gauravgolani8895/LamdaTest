package demoBlaze;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SignUp extends BasePage {
	
@Test
public void signup() throws InterruptedException
{
	WebElement signup = driver.findElement(By.xpath("//a[contains(text(),'Sign up')]")) ;
	signup.click();
	
	WebElement Username = driver.findElement(By.xpath("//input[@id='sign-username']"));
	Username.sendKeys("gaurav_golani");
	
	WebElement pwd = driver.findElement(By.xpath("//input[@id='sign-password']"));
	pwd.sendKeys("gaurav123");
	
	driver.findElement(By.xpath("//button[contains(text(),'Sign up')]")).click();
	Thread.sleep(3000);
	System.out.println(driver.switchTo().alert().getText());
	driver.switchTo().alert().accept();
}
}
